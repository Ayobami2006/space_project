$(".owl-carousel .item").click(function(){
    debugger;
    window.href = "screen1.html";
})